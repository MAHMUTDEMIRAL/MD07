import random

class Karakter:
    def __init__(self, adi, can, guc, ceviklik, dayaniklilik):
        self.adi = adi
        self.can = can
        self.guc = guc
        self.ceviklik = ceviklik
        self.dayaniklilik = dayaniklilik

class Oyuncu(Karakter):
    def __init__(self, adi, enstruman, para=10, seviye=1, tecrube=0):
        super().__init__(adi, can=100, guc=1, ceviklik=1, dayaniklilik=1)
        self.enstruman = enstruman
        self.para = para
        self.seviye = seviye
        self.tecrube = tecrube
        self.temel_nitelikler = {'tokluk': 100, 'hijyen': 100, 'eglence': 100, 'uykusuzluk': 0}
        self.beceriler = {'guc': 1, 'ceviklik': 1, 'dayaniklilik': 1, 'karizma': 1, 'toplayicilik': 1}

def senaryo():
    print("**Ozanın Maceraları Oyununa Hoşgeldiniz**\nAşağdaki hikayeyi okuyup size sunulan seçekler ile ozanımızı yönlendirin.\n***HİKAYE***\nİsmini sizin belirlediğiniz ozanımız sizin istediğiniz çalgısı ile kendi halinde yaşayan ve müzik söyleyip hayatına devam eden biridir.\nKamp yapmayı seven ozanımızın en sevdiği aktivitelerinden birisi kamp ateşi başında çalgı çalıp müzik söylemek.\nOsmanlı İmparatorluğu'nun kuruluş dönemlerinde yaşayan ozanımız aynı zamanda tasavvufu kendine yol bilen bir derviştir.\nOzanımız Osmanoğulları Beyliğinde yaşayıp Osman Gazi ile çok yakın dosttur.\nAnadolu zor dönemlerden geçmektedir.Moğol istilası yüzünden bölgede kan gövdeyi götürmektedir.\nAynı zamanda bir yandan Roma İmparatorluğu da bölgede Türkleri istemediğinden yer yer Türklere zulüm etmektedir.\nOzanımız zaman zaman keşfe çıkınca Bizans/Moğol haydutları ile savaşmak zorunda kalmaktadır.\nOzanımız savaşmayı sevmeyen her şeyin sükut ile halledilmesinden yana olan kendi halinde bir insandır.\nLakin gelecek olan o  sükutun savaşsız olmayacağı kesindir.Ozanımız kurulacak olan Osmanlı İmparatorluğu için Osman Gazi'nin tam destekçisidir.\nBu yuzden zaman zaman onun için keşfe çıkar hatta Osman Gazi ile seferlere dahi katılır.\nOzanınmızın tek isteği Anadoluda barışın sağlanması ve kardeş kanının dökülmemesidir.Bu barışı sağlayacak kişinin Osman Gazi olduğunu düşünen ozanımız onun hep yanında olup destekçisi olacaktır. \nBu serüvende ozanımıza eşlik edip neler olcağını hep birlikte görelim.\n**İYİ OYUNLAR**   ")

    def durumu_goster(self):
        print(f"Adı: {self.adi}")
        print(f"Enstrumanı: {self.enstruman}")
        print(f"Parası: {self.para}")
        print(f"Seviyesi: {self.seviye}")
        print(f"Tecrübe Puanı: {self.tecrube}")
        print("Temel Nitelikler:")
        for nitelik, deger in self.temel_nitelikler.items():
            print(f"{nitelik.capitalize()}: {deger}")
        print("Beceriler:")
        for beceri, deger in self.beceriler.items():
            print(f"{beceri.capitalize()}: {deger}")

def kamp_alani(oyuncu):
    print("Kamp alanına gittiniz.")
    while True:
        print("\nKamp Alanı Seçenekleri:")
        print("1. Kamp ateşinin başında çalgı çal ve şarkı söyle")
        print("2. Nehirde yıkan")
        print("3. Çadırına girip uyu")
        print("4. Köy meydanına dön")

        secim = input("Seçiminizi yapın: ")

        if secim == "1":
            print("Kamp ateşinin başında çalgı çaldınız.")
            oyuncu.beceriler['eglence'] = 20
            oyuncu.tecrube += 10
        elif secim == "2":
            print("Nehirde yıkandınız.")
            oyuncu.temel_nitelikler['hijyen'] = 100
        elif secim == "3":
            print("Çadırınıza girip uyudunuz.")
            oyuncu.temel_nitelikler['uykusuzluk'] = 0
        elif secim == "4":
            print("Köy meydanına geri döndünüz.")
            break
        else:
            print("Geçersiz seçim!")

def sifahane(oyuncu):
    print("Şifahaneye gittiniz.")
    while True:
        print("\nŞifahane Seçenekleri:")
        print("1. Şifacıdan yaralarını sarmasını iste")
        print("2. Şifacıdan merhem yapıp sürmesini iste")
        print("3. Köy meydanına dön")

        secim = input("Seçiminizi yapın: ")

        if secim == "1":
            print("Şifacıdan yaralarınızı sardırdınız.")
            oyuncu.can += 20
        elif secim == "2":
            print("Şifacıdan merhem sürdünüz.")
            oyuncu.can += 50
        elif secim == "3":
            print("Köy meydanına geri döndünüz.")
            break
        else:
            print("Geçersiz seçim!")

def hana(oyuncu):
    print("Hanaya gittiniz.")
    while True:
        print("\nHana Seçenekleri:")
        print("1. Yiyecek satın al ve ye")
        print("2. İçecek satın al ve iç")
        print("3. Enstrüman çal ve şarkı söyle")
        print("4. Köy meydanına dön")

        secim = input("Seçiminizi yapın: ")

        if secim == "1":
            print("Yiyecek satın alıp yediniz.")
            oyuncu.temel_nitelikler['tokluk'] += 50
            oyuncu.para -= 10
        elif secim == "2":
            print("İçecek satın aldınız ve içtiniz.")
            oyuncu.temel_nitelikler['tokluk'] += 10
            oyuncu.temel_nitelikler['eglence'] += 50
            oyuncu.para -= 5
        elif secim == "3":
            print("Enstrüman çaldınız ve şarkı söylediniz.")
            oyuncu.temel_nitelikler['eglence'] += 10
            oyuncu.tecrube += 20
            oyuncu.para += 10
        elif secim == "4":
            print("Köy meydanına geri döndünüz.")
            break
        else:
            print("Geçersiz seçim!")

def maceraya_atil(oyuncu):
    print("Maceraya atıldınız.")
    while True:
        print("\nMaceraya Atılma Seçenekleri:")
        print("1. Yakın çevreden şifalı bitki topla ve avlan")
        print("2. Ormanı keşfe çık (kolay)")
        print("3. Kayalıkları keşfe çık (orta)")
        print("4. Vadiyi keşfe çık (zor)")
        print("5. Köy meydanına dön")

        secim = input("Seçiminizi yapın: ")

        if secim == "1":
            print("Yakın çevreden şifalı bitkiler topladınız ve avlandınız.")
            toplam_ihtimal = random.randint(1, 100)
            if toplam_ihtimal <= 40:
                print("Şifalı bitkiler buldunuz!")
                oyuncu.can += 10
                print("Canınız arttı!")
            elif toplam_ihtimal <= 80:
                print("Meyve topladınız!")
                oyuncu.temel_nitelikler['tokluk'] += 20
                print("Tokluğunuz arttı!")
            else:
                print("Avlandınız!")
                oyuncu.temel_nitelikler['tokluk'] += 50
                print("Tokluğunuz arttı!")
        elif secim == "2":
            print("Ormanı keşfe çıktınız.")
            
            haydut_gucler = {'guc_min': 1, 'guc_max': 5, 'ceviklik_min': 1, 'ceviklik_max': 5, 'dayaniklilik': 50}
            savas_macerasi(oyuncu, haydut_gucler)
        elif secim == "3":
            print("Kayalıkları keşfe çıktınız.")
            
            haydut_gucler = {'guc_min': 6, 'guc_max': 10, 'ceviklik_min': 6, 'ceviklik_max': 10, 'dayaniklilik': 70}
            savas_macerasi(oyuncu, haydut_gucler)
        elif secim == "4":
            print("Vadiyi keşfe çıktınız.")
            
            haydut_gucler = {'guc_min': 11, 'guc_max': 15, 'ceviklik_min': 11, 'ceviklik_max': 15, 'dayaniklilik': 90}
            savas_macerasi(oyuncu, haydut_gucler)
        elif secim == "5":
            print("Köy meydanına geri döndünüz.")
            break
        else:
            print("Geçersiz seçim!")

def savas_macerasi(oyuncu, haydut_gucler):
    haydut_can = 50  # Haydutun başlangıç canı
    haydut_guc = random.randint(haydut_gucler['guc_min'], haydut_gucler['guc_max'])
    haydut_ceviklik = random.randint(haydut_gucler['ceviklik_min'], haydut_gucler['ceviklik_max'])

    print(f"Karşınıza bir haydut çıktı! Gücü: {haydut_guc}, Çevikliği: {haydut_ceviklik}, Canı: {haydut_can}")

    while oyuncu.can > 0 and haydut_can > 0:
        oyuncu_savas_hamlesi = input("Saldırı yapmak için 's', Kaçmak için 'k' tuşuna basın: ").lower()
        if oyuncu_savas_hamlesi == 's':
            saldiri_gucu = oyuncu.beceriler['guc'] * 4
            haydut_savunma = haydut_can - (haydut_can * (4 * haydut_ceviklik / 100 - 1))
            print(f"Saldiri Gucu: {saldiri_gucu}")
            print(f"Haydutun savunması: {haydut_savunma}")
            haydut_can -= max(0, saldiri_gucu - haydut_savunma)
            print(f"Haydutun kalan canı: {haydut_can}")
            if haydut_can <= 0:
                print("Haydutu yendiniz!")
                oyuncu.tecrube += 30
                oyuncu.para += 30
        elif oyuncu_savas_hamlesi == 'k':
            kaçis_ihtimali = random.randint(2 * oyuncu.beceriler['ceviklik'], 100)
            if kaçis_ihtimali > 50:
                print("Başarıyla kaçtınız!")
                break
            else:
                print("Kaçış başarısız oldu!")
                savas_hamlesi = 's'
        else:
            print("Geçersiz seçim!")
            continue

        if oyuncu.can <= 0:
            print("Maalesef, haydut sizi yendi!")
            print("Oyun bitti!")
            exit()
    else:
        print("Haydut sizi yendi!")
        print("Oyun bitti!")
        exit()



    print(f"Karşınıza bir haydut çıktı! Gücü: {haydut_guc}, Çevikliği: {haydut_ceviklik}, Canı: {haydut_can}")

    while oyuncu.can > 0 and haydut_can > 0:
        oyuncu_savas_hamlesi = input("Saldırı yapmak için 's', Kaçmak için 'k' tuşuna basın: ").lower()
        if oyuncu_savas_hamlesi == 's':
            saldiri_gucu = oyuncu.beceriler['guc'] * 4
            haydut_savunma = haydut_can - (haydut_can * (4 * haydut_ceviklik / 100 - 1))
            print(f"Saldiri Gucu: {saldiri_gucu}")
            print(f"Haydutun savunması: {haydut_savunma}")
            haydut_can -= max(0, saldiri_gucu - haydut_savunma)
            print(f"Haydutun kalan canı: {haydut_can}")
            if haydut_can <= 0:
                print("Haydutu yendiniz!")
                oyuncu.tecrube += 30
                oyuncu.para += 30
        elif oyuncu_savas_hamlesi == 'k':
            kaçis_ihtimali = random.randint(2 * oyuncu.beceriler['ceviklik'], 100)
            if kaçis_ihtimali > 50:
                print("Başarıyla kaçtınız!")
                break
            else:
                print("Kaçış başarısız oldu!")
                savas_hamlesi = 's'
        else:
            print("Geçersiz seçim!")
            continue

        if oyuncu.can <= 0:
            print("Maalesef, haydut sizi yendi!")
            print("Oyun bitti!")
            exit()
    else:
        print("Haydut sizi yendi!")
        print("Oyun bitti!")
        exit()

def seviye_atla(oyuncu):
    if oyuncu.tecrube >= 100:
        print("Seviye atlandı!")
        print("Hangi beceriyi geliştirmek istersiniz?")
        print("1. Güç")
        print("2. Çeviklik")
        print("3. Dayanıklılık")
        print("4. Karizma")
        print("5. Toplayıcılık")

        secim = input("Seçiminizi yapın: ")

        if secim in ["1", "2", "3", "4", "5"]:
            oyuncu.beceriler[secim] += 1
            oyuncu.tecrube = 0
            print(f"{secim}. beceri geliştirildi!")
        else:
            print("Geçersiz seçim!")
    else:
        print("Tecrübeniz henüz yeterli değil!")


def oyun():
    senaryo()
    oyuncu_adi = input("Oyuncu adınızı girin: ")
    enstruman = input("Karakterinizin enstrumanını seçin: ")
    oyuncu = Oyuncu(oyuncu_adi, enstruman)
    

    while True:
        print("\nKöy Meydanı Seçenekleri:")
        print("1. Kamp Alanı")
        print("2. Şifahane")
        print("3. Hana")
        print("4. Maceraya Atıl")
        print("5.Seviye Atla")
        print("6. Durumu GÖster")
        print("7. Oyundan Çık")

        secim = input("Seçiminizi yapın: ")

        if secim == "1":
            kamp_alani(oyuncu)
        elif secim == "2":
            sifahane(oyuncu)
        elif secim == "3":
            hana(oyuncu)
        elif secim == "4":
            maceraya_atil(oyuncu)
        elif secim == "5":
            seviye_atla(oyuncu)
        elif secim == "6":
            oyuncu.durumu_goster()
        elif secim == "7":
            print("Oyundan çıkılıyor...")
            break
        else:
            print("Geçersiz seçim!")

        seviye_atla(oyuncu)
        oyuncu.durumu_goster()

if __name__ == "__main__":
    oyun()
